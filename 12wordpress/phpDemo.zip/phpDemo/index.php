<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
<!-- phpDemo.php - Show how to use PHP
  Peter Johnson - peterk@webExplorations.com
  Written:   08-08-13 
  Revised:   
  -->
 <title>PHP Demo</title>

<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<!-- 
     Use PHP to include menu items on every page
     This page must be run on a server to get the PHP to happen 
-->
<?php
include "menu.php";
?>

<h1>Using PHP - Server-Side Includes</h1>

<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi semper fermentum turpis vestibulum rhoncus. Pellentesque sit amet nunc ut urna pharetra fringilla vel ac nibh. Etiam dolor risus, luctus et libero eu, mollis tincidunt nulla. Phasellus bibendum dictum sem, non vestibulum ipsum tempus at. Aliquam vel felis erat. Sed luctus enim eu augue dapibus, vitae semper augue ornare. Vivamus pellentesque mattis arcu, ut ultrices nunc mollis sed. Sed malesuada non elit ut vehicula. Nunc quis felis et turpis pellentesque dictum. Nullam eget condimentum metus. In vehicula augue sit amet quam viverra laoreet.
</p>
<p>
Interdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur turpis velit, tempor non risus ac, iaculis iaculis orci. Curabitur ornare purus nec pretium suscipit. Duis a eleifend urna, et mattis turpis. Curabitur ornare, nibh nec porta commodo, arcu nisl congue nisi, in molestie velit nibh sed odio. Ut ullamcorper nunc ut ullamcorper faucibus. Quisque porta, tellus sit amet molestie commodo, enim justo pharetra odio, sed lobortis arcu diam vitae felis. Sed vel nisl sit amet lacus tincidunt porttitor quis sit amet odio. Maecenas dictum congue est quis pulvinar. Quisque non sem eu nisi tincidunt venenatis nec sit amet sem. Proin ultricies interdum nulla. Vestibulum dui leo, porta eget aliquam sit amet, vehicula tristique est. Pellentesque erat erat, pretium sed lorem id, rhoncus accumsan risus. Mauris tincidunt mattis tellus. Donec vehicula sapien eu justo sollicitudin gravida.
</p>
<p>
Sed est lorem, vestibulum at suscipit a, tincidunt et odio. Nunc consectetur, nunc ac euismod lacinia, nulla tortor dignissim nisi, et viverra mi quam id erat. Quisque vitae odio sed libero laoreet pellentesque. Cras at pellentesque nisi, a suscipit magna. Praesent lobortis scelerisque urna sit amet blandit. Curabitur eget condimentum magna. Donec porttitor justo non magna vehicula iaculis. Praesent vulputate purus sit amet luctus rutrum. Vestibulum venenatis eu nisl quis rutrum. Maecenas mollis porta massa, ut iaculis arcu hendrerit id. Aliquam ac lacinia risus. Aliquam ac libero accumsan ante lacinia cursus. Nulla porta nunc a dapibus fringilla. Integer laoreet lacus magna, non pharetra nibh adipiscing quis. Vestibulum diam tortor, iaculis a lorem adipiscing, tincidunt ornare eros. Maecenas dapibus purus sit amet enim hendrerit pharetra.
</p>
<p>
Interdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur eget dui sed nulla commodo mattis sit amet ut orci. Nulla congue semper enim nec lacinia. Fusce dictum elementum blandit. Sed iaculis pellentesque metus interdum molestie. Nunc faucibus nec ante ac porttitor. Nunc vitae nisi sit amet metus adipiscing vulputate vel ut nulla. Aliquam in lacus tortor.
</p>
<p>
Donec faucibus facilisis leo, fermentum molestie nulla hendrerit et. Sed sagittis blandit metus at blandit. Mauris eget condimentum nibh. Ut consectetur dolor in imperdiet tristique. Praesent nec mauris fringilla, ullamcorper dui tristique, dapibus urna. Nulla hendrerit imperdiet sollicitudin. Curabitur ornare aliquet dui ut malesuada. Vestibulum id aliquam lacus. Pellentesque gravida congue diam, a mattis dolor dapibus vel.
</p>

</frame>
</body>
</html>
