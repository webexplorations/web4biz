<!-- menu.php - partial web page used to build menu system for the site
     Peter K. Johnson - peter.johnson@southCentral.edu
     Written:    05-06-14
     Revised:    05-06-14
-->

<div id="nav-menu">
   <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="resume.php">My Resume</a></li>
      <li><a href="link.php">My Work</a></li>
      <li><a href="friend.php">Links</a></li>
   </ul>
</div>
<br />