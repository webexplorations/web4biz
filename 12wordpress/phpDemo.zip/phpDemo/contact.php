<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
<!-- contact.php - My contact information
  Peter Johnson - peterk@webExplorations.com
  Written:   08-08-13 
  Revised:   
  -->
 <title>PHP Demo</title>

<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<!-- 
     Use PHP to include menu items on every page
     This page must be run on a server to get the PHP to happen 
-->
<?php
include "menu.php";
?>

<h1>My Contact Information</h1>

<p>
<strong>Peter K. Johnson</strong> - Instructional Designer<br />
1920 Lee Boulevard<br />
North Mankato, MN 56003<br />
<br />
507-389-7337<br />
<a href="http://pedroj.t.southcentral.edu" target="_new">My Web Site</a><br />
Email:  peter.johnson@southCentral.edu
</p>

</frame>
</body>
</html>
